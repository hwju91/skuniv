package winder.vo;

public class MembersVO {

	int mno, tno;
	String state, id;
	
	public int getMno() {
		return mno;
	}
	public void setMno(int mno) {
		this.mno = mno;
	}
	public int getTno() {
		return tno;
	}
	public void setTno(int tno) {
		this.tno = tno;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	@Override
	public String toString() {
		return "MembersVO [mno=" + mno + ", tno=" + tno + ", state=" + state + ", id=" + id + "]";
	}
	
}
